S5_Delete_Ticket()
{
	int i;
	int Count;
	char number[50]; 
	
	lr_start_transaction("Delete_Ticket");

	web_reg_find("Text=Welcome to the Web Tours site",LAST);
	lr_start_transaction("GotoWebTours");

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Priority", 
		"u=0, i");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

/*Correlation comment - Do not change!  Original value='140072.372377481HcAtQHcpzftVzzzHtDccQpiDfQcf' Name ='userSession' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=userSession",
		"LB=name=\"userSession\" value=\"",
		"RB=\"/>\n<table border",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/nav.pl*",
		LAST);

	web_url("WebTours", 
		"URL=http://127.0.0.1:1080/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Site");

	web_add_auto_header("Priority", 
		"u=2");

	lr_end_transaction("GotoWebTours",LR_AUTO);

	
	web_reg_find("Text=Welcome, <b>{username}</b>, to the Web Tours",LAST);
	lr_start_transaction("LogIn");

	web_add_header("Origin", 
		"http://127.0.0.1:1080");

	web_add_auto_header("Priority", 
		"u=4");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(7);

	web_submit_data("login.pl",
		"Action=http://127.0.0.1:1080/cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?in=home",
		"Snapshot=t30.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession}", ENDITEM,
		"Name=username", "Value={username}", ENDITEM,
		"Name=password", "Value={password}", ENDITEM,
		"Name=login.x", "Value=67", ENDITEM,
		"Name=login.y", "Value=2", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		LAST);

	lr_end_transaction("LogIn",LR_AUTO);

	
	web_reg_find("Text=Itinerary",LAST);
	lr_start_transaction("GotoItinerary");

	web_revert_auto_header("Sec-Fetch-User");

	lr_think_time(8);

/*Correlation comment - Do not change!  Original value='6315-808-JB' Name ='flightID' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=flightID",
		"LB=name=\"flightID\" value=\"",
		"RB=\"  ",
		"Ordinal=All",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/itinerary.pl*",
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='4' 
Name ='CorrelationParameter' 
Type ='Manual'*/
	web_reg_save_param_ex(
		"ParamName=cgifields",
		"LB/IC=name=\".cgifields\" value=\"",
		"RB/IC=\"",
		"Ordinal=All",
		SEARCH_FILTERS,
		"Scope=Body",
		"RequestUrl=*/itinerary.pl*",
		LAST);

	web_url("Itinerary Button", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("GotoItinerary",LR_AUTO);

	
	
	lr_start_transaction("CancelChecked");

	web_add_header("Origin", 
		"http://127.0.0.1:1080");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	lr_think_time(10);

    lr_save_string("", "temp");

    for (i=1;i<=2;i++){
        lr_param_sprintf("temp", "%s%d=on&", lr_eval_string("{temp}"), i);
    }

    lr_param_sprintf("temp",
    "%s=on&",
    lr_eval_string("{flightID_count}"));

    for (i=1;i<=atoi(lr_eval_string("{flightID_count}"));i++)
    {
        lr_param_sprintf("temp",
        "%sflightID=%s&",
        lr_eval_string("{temp}"),
        lr_paramarr_idx("flightID",
        i));

        lr_param_sprintf("temp",
        "%s.cgifields=%s&",
        lr_eval_string("{temp}"),
        lr_paramarr_idx("cgifields",
        i));
    }

    lr_save_string(lr_eval_string("{temp}removeFlights.x=36&removeFlights.y=4"), "body");

    lr_save_string(lr_eval_string(lr_eval_string("{flightID_{flightID_count}}")),
    "cancelflight");
    
    web_reg_find("Text={cancelflight}", "Fail=Found", LAST);
    
    web_custom_request("itinerary.pl_2",
    "URL=http://127.0.0.1:1080/cgi-bin/itinerary.pl",
    "Method=POST",
    "Resource=0",
    "RecContentType=text/html",
    "Referer=http://127.0.0.1:1080/cgi-bin/itinerary.pl",
		"Snapshot=t32.inf",
		"Mode=HTML",
		"Body={body}",
    LAST);
	
	lr_end_transaction("CancelChecked",LR_AUTO);
	
	
	web_reg_find("Text=Welcome to the Web Tours site",LAST);
	lr_start_transaction("LogOut");

	web_revert_auto_header("Sec-Fetch-User");

	lr_think_time(8);

	web_url("SignOff Button", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("LogOut",LR_AUTO);
	
	lr_end_transaction("Delete_Ticket", LR_AUTO);


	return 0;
}