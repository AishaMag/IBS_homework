S2_Ticket_Search()
{

	lr_start_transaction("GotoWebTours");

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Priority", 
		"u=0, i");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("WebTours", 
		"URL=http://127.0.0.1:1080/WebTours/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("GotoWebTours",LR_AUTO);

	lr_start_transaction("LogIn");

	web_revert_auto_header("Sec-Fetch-User");

	web_add_header("Origin", 
		"http://127.0.0.1:1080");

	web_add_auto_header("Priority", 
		"u=4");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_submit_form("login.pl", 
		"Snapshot=t13.inf", 
		ITEMDATA, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		LAST);

	lr_end_transaction("LogIn",LR_AUTO);

	lr_start_transaction("GotoFlights");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(10);

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t14.inf", 
		LAST);

	lr_end_transaction("GotoFlights",LR_AUTO);

	web_add_header("Origin", 
		"http://127.0.0.1:1080");

	lr_think_time(5);

	web_submit_form("reservations.pl", 
		"Snapshot=t15.inf", 
		ITEMDATA, 
		"Name=depart", "Value=Frankfurt", ENDITEM, 
		"Name=departDate", "Value=10/02/2024", ENDITEM, 
		"Name=arrive", "Value=San Francisco", ENDITEM, 
		"Name=returnDate", "Value=10/13/2024", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=<OFF>", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		LAST);

	lr_start_transaction("FindFlight");

	lr_end_transaction("FindFlight",LR_AUTO);

	lr_start_transaction("LogOff");

	web_revert_auto_header("Sec-Fetch-User");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_image("Home Button", 
		"Alt=Home Button", 
		"Snapshot=t16.inf", 
		LAST);

	lr_end_transaction("LogOff",LR_AUTO);

	web_revert_auto_header("Sec-Fetch-User");

	lr_think_time(5);

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t17.inf", 
		LAST);

	return 0;
}