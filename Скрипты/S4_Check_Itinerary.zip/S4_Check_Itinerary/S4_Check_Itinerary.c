S4_Check_Itinerary()
{
	
	lr_start_transaction("Check_Itinerary");


	lr_start_transaction("GotoWebTours");

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_header("Priority", 
		"u=2");

	web_custom_request("wr2", 
		"URL=http://o.pki.goog/wr2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0R0P0N0L0J0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14SB\\xD4\\x84\\x8B\\xC1\\x17\\xF9\\xB6\\x14Mw|\\xFB#1\\x0F{5\\xCD\\x04\\x14\\xDE\\x1B\\x1E\\xEDy\\x15\\xD4>7$\\xC3!\\xBB\\xEC49mB\\xB20\\x02\\x11\\x00\\xE6p\\xCC?\\xA3M\\xEC#\\x10\\x01\\x89[yxH%", 
		LAST);

	web_add_auto_header("Priority", 
		"u=4");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_reg_find("Text=Welcome to the Web Tours site",LAST);
	web_url("welcome.pl", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?signOff=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/WebTours/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("GotoWebTours",LR_AUTO);

	
	
	web_reg_find("Text=Welcome, <b>{username}</b>, to the Web Tours",LAST);
	lr_start_transaction("logIn");

	web_add_header("Origin", 
		"http://127.0.0.1:1080");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	lr_think_time(6);

	web_submit_form("login.pl", 
		"Snapshot=t13.inf", 
		ITEMDATA, 
		"Name=username", "Value={username}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		LAST);

	lr_end_transaction("logIn",LR_AUTO);
	
	

	web_reg_find("Text=Itinerary",LAST);
	lr_start_transaction("GotoItinerary");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(10);

	web_image("Itinerary Button", 
		"Alt=Itinerary Button", 
		"Snapshot=t14.inf", 
		LAST);

	lr_end_transaction("GotoItinerary",LR_AUTO);
	
	
	
	web_reg_find("Text=Welcome to the Web Tours site",LAST);
	lr_start_transaction("LogOff");
	
	web_add_header("Sec-Fetch-User", 
		"?1");

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t15.inf", 
		LAST);

	lr_end_transaction("LogOff",LR_AUTO);
	
	lr_end_transaction("Check_Itinerary", LR_AUTO);


	return 0;
}