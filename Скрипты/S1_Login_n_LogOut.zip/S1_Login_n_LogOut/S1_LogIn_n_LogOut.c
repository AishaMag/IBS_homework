S1_LogIn_n_LogOut()
{
	lr_start_transaction("LogIn_n_LogOut");


	web_reg_find("Text=Welcome to the Web Tours site",LAST);
	
	lr_start_transaction("GotoWebTours");

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Priority", 
		"u=0, i");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("WebTours", 
		"URL=http://127.0.0.1:1080/WebTours/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("GotoWebTours",LR_AUTO);
	
	

	web_reg_find("Text=Welcome, <b>{username}</b>, to the Web Tours",LAST);
	lr_start_transaction("LogIn");

	web_revert_auto_header("Sec-Fetch-User");

	web_add_header("Origin", 
		"http://127.0.0.1:1080");

	web_add_auto_header("Priority", 
		"u=4");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	lr_think_time(8);

	web_submit_form("login.pl", 
		"Snapshot=t11.inf", 
		ITEMDATA, 
		"Name=username", "Value={username}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		LAST);

	lr_end_transaction("LogIn",LR_AUTO);
	
	

	web_reg_find("Text=Welcome to the Web Tours site",LAST);
	lr_start_transaction("LogOut");

	web_add_header("Sec-Fetch-User", 
		"?1");

	lr_think_time(8);

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t12.inf", 
		LAST);

	lr_end_transaction("LogOut",LR_AUTO);
	
	
	lr_end_transaction("LogIn_n_LogOut", LR_AUTO);


	return 0;
}