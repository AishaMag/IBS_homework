S6_SignUp()
{
	
	lr_start_transaction("Sign_Up");


	web_reg_find("Text=Welcome to the Web Tours site",LAST);
	lr_start_transaction("GotoWebTours");

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_header("Priority", 
		"u=4");

	web_add_header("Sec-Fetch-Dest", 
		"frame");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("welcome.pl", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/WebTours/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Priority", 
		"u=2");

	web_custom_request("wr2", 
		"URL=http://o.pki.goog/wr2", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0R0P0N0L0J0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14SB\\xD4\\x84\\x8B\\xC1\\x17\\xF9\\xB6\\x14Mw|\\xFB#1\\x0F{5\\xCD\\x04\\x14\\xDE\\x1B\\x1E\\xEDy\\x15\\xD4>7$\\xC3!\\xBB\\xEC49mB\\xB20\\x02\\x11\\x00\\xC2\\x0E\\xDE\\xAEc!\\x12x\n\\x10N\\xB4\\xAB\\xD8\\xBD\\x83", 
		LAST);

	lr_end_transaction("GotoWebTours",LR_AUTO);

	
	web_reg_find("Text=Customer Profile",LAST);
	lr_start_transaction("SignUp");

	web_add_auto_header("Priority", 
		"u=4");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(7);

	web_url("login.pl", 
		"URL=http://127.0.0.1:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/WebTours/home.html", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	
	web_reg_find("Text=Thank you, <b>{username}</b>, for registering and welcome to the Web Tours family",LAST);
	lr_start_transaction("CustomerProfile");

	web_add_header("Origin", 
		"http://127.0.0.1:1080");

	lr_think_time(15);

	web_submit_data("login.pl_2", 
		"Action=http://127.0.0.1:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=info", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={username}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=passwordConfirm", "Value={password}", ENDITEM, 
		"Name=firstName", "Value={firstname}", ENDITEM, 
		"Name=lastName", "Value={lastname}", ENDITEM, 
		"Name=address1", "Value={street}", ENDITEM, 
		"Name=address2", "Value={city}", ENDITEM, 
		"Name=register.x", "Value=59", ENDITEM, 
		"Name=register.y", "Value=9", ENDITEM, 
		LAST);

	lr_end_transaction("CustomerProfile",LR_AUTO);

	
	
	web_revert_auto_header("Sec-Fetch-User");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	lr_think_time(9);

	web_url("button_next.gif", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=menus", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/login.pl", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("SignUp",LR_AUTO);

	
	
	web_reg_find("Text=Welcome to the Web Tours site",LAST);
	lr_start_transaction("LogOut");

	web_revert_auto_header("Sec-Fetch-User");

	lr_think_time(4);

	web_url("SignOff Button", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("LogOut",LR_AUTO);
	
	
	lr_end_transaction("Sign_Up", LR_AUTO);


	return 0;
}